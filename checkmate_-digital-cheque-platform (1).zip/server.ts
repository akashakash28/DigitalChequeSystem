import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import { v4 as uuidv4 } from "uuid";
import crypto from "crypto";
import dotenv from "dotenv";
import { WebSocketServer, WebSocket } from "ws";
import http from "http";

dotenv.config();

const db = new Database(process.env.DATABASE_URL || "cheque_platform.db");

// Initialize Database with new fields
try {
  db.exec(`ALTER TABLE cheques ADD COLUMN payment_type TEXT DEFAULT 'CHEQUE'`);
} catch (e) {}
try {
  db.exec(`ALTER TABLE cheques ADD COLUMN sla_deadline DATETIME`);
} catch (e) {}
try {
  db.exec(`ALTER TABLE cheques ADD COLUMN cleared_at DATETIME`);
} catch (e) {}
try {
  db.exec(`ALTER TABLE cheques ADD COLUMN sender_face_auth BOOLEAN DEFAULT 0`);
} catch (e) {}
try {
  db.exec(`ALTER TABLE cheques ADD COLUMN receiver_face_auth BOOLEAN DEFAULT 0`);
} catch (e) {}
try {
  db.exec(`ALTER TABLE cheques ADD COLUMN bank_notes TEXT`);
} catch (e) {}

try {
  db.exec(`ALTER TABLE cheques ADD COLUMN secret_key TEXT`);
} catch (e) {}

db.exec(`
  CREATE TABLE IF NOT EXISTS cheques (
    id TEXT PRIMARY KEY,
    payee TEXT NOT NULL,
    amount REAL NOT NULL,
    amount_words TEXT,
    purpose TEXT,
    cheque_date TEXT NOT NULL,
    status TEXT DEFAULT 'SUBMITTED',
    hash TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    sender_id TEXT,
    receiver_id TEXT,
    image_data TEXT,
    risk_score INTEGER DEFAULT 0,
    tampered BOOLEAN DEFAULT 0,
    payment_type TEXT DEFAULT 'CHEQUE',
    sla_deadline DATETIME,
    cleared_at DATETIME,
    sender_face_auth BOOLEAN DEFAULT 0,
    receiver_face_auth BOOLEAN DEFAULT 0,
    bank_notes TEXT,
    secret_key TEXT
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cheque_id TEXT,
    action TEXT NOT NULL,
    user_id TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    ip_address TEXT,
    device_id TEXT
  );
`);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json({ limit: '50mb' }));

// WebSocket broadcasting
function broadcast(data: any) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

// Helper to log audit events
function logAudit(chequeId: string, action: string, userId: string, details: string) {
  const stmt = db.prepare("INSERT INTO audit_logs (cheque_id, action, user_id, details) VALUES (?, ?, ?, ?)");
  stmt.run(chequeId, action, userId, details);
  broadcast({ type: 'AUDIT_LOG', data: { cheque_id: chequeId, action, user_id: userId, details, timestamp: new Date().toISOString() } });
}

// Helper to calculate hash
function calculateChequeHash(cheque: any) {
  const data = `${cheque.payee}|${cheque.amount}|${cheque.cheque_date}|${cheque.purpose}`;
  return crypto.createHash('sha256').update(data).digest('hex');
}

// API Routes
app.get("/api/cheques", (req, res) => {
  const cheques = db.prepare("SELECT * FROM cheques ORDER BY created_at DESC").all();
  res.json(cheques);
});

app.get("/api/audit-logs", (req, res) => {
  const logs = db.prepare("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100").all();
  res.json(logs);
});

app.get("/api/risk-stats", (req, res) => {
  const stats = db.prepare(`
    SELECT 
      COUNT(*) as total,
      SUM(CASE WHEN risk_score > 70 THEN 1 ELSE 0 END) as high_risk,
      SUM(CASE WHEN tampered = 1 THEN 1 ELSE 0 END) as tampered_count,
      AVG(risk_score) as avg_risk
    FROM cheques
  `).get();
  res.json(stats);
});

app.get("/api/cheques/:id", (req, res) => {
  const cheque = db.prepare("SELECT * FROM cheques WHERE id = ?").get(req.params.id);
  if (!cheque) return res.status(404).json({ error: "Cheque not found" });
  
  const logs = db.prepare("SELECT * FROM audit_logs WHERE cheque_id = ? ORDER BY timestamp DESC").all(req.params.id);
  res.json({ ...cheque, logs });
});

app.post("/api/cheques", (req, res) => {
  const { payee, amount, purpose, cheque_date, image_data, amount_words, payment_type, sender_face_auth, secret_key } = req.body;
  
  // Real-world check: Secret Key must be "1234" for this demo
  if (secret_key !== "1234") {
    return res.status(401).json({ error: "Invalid Secret Authorization Key" });
  }

  const id = uuidv4();
  const hash = calculateChequeHash({ payee, amount, cheque_date, purpose });
  
  // SLA Calculation
  const slaHours = payment_type === 'RTGS' ? 2 : (payment_type === 'NEFT' ? 24 : 48);
  const sla_deadline = new Date(Date.now() + slaHours * 60 * 60 * 1000).toISOString();

  // Basic Risk Scoring
  let risk_score = 0;
  if (amount > 100000) risk_score += 30;
  if (!sender_face_auth) risk_score += 15;

  const stmt = db.prepare(`
    INSERT INTO cheques (id, payee, amount, amount_words, purpose, cheque_date, image_data, risk_score, payment_type, sla_deadline, sender_face_auth, status, secret_key, hash)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED', ?, ?)
  `);
  
  stmt.run(id, payee, amount, amount_words, purpose, cheque_date, image_data, risk_score, payment_type || 'CHEQUE', sla_deadline, sender_face_auth ? 1 : 0, secret_key, hash);
  
  logAudit(id, "SUBMITTED", "SENDER_USER", `Transaction submitted to bank. Secret key verified. Risk: ${risk_score}`);
  broadcast({ type: 'CHEQUE_CREATED', data: { id, payee, amount, status: 'SUBMITTED' } });
  
  res.json({ id, status: "SUBMITTED" });
});

app.post("/api/cheques/:id/transition", (req, res) => {
  const { status, userId, receiver_face_auth, bank_notes } = req.body;
  const chequeId = req.params.id;
  
  const cheque = db.prepare("SELECT * FROM cheques WHERE id = ?").get(chequeId) as any;
  if (!cheque) return res.status(404).json({ error: "Cheque not found" });

  // Tamper Check
  if (cheque.hash) {
    const currentHash = calculateChequeHash(cheque);
    if (currentHash !== cheque.hash) {
      db.prepare("UPDATE cheques SET tampered = 1 WHERE id = ?").run(chequeId);
      logAudit(chequeId, "TAMPER_DETECTED", "SYSTEM", "Cheque data mismatch with original hash!");
      broadcast({ type: 'RISK_ALERT', data: { cheque_id: chequeId, type: 'TAMPER' } });
      return res.status(400).json({ error: "Cheque integrity compromised" });
    }
  }

  const cleared_at = status === 'CLEARED' ? new Date().toISOString() : null;
  db.prepare(`
    UPDATE cheques 
    SET status = ?, 
        cleared_at = COALESCE(?, cleared_at),
        receiver_face_auth = COALESCE(?, receiver_face_auth),
        bank_notes = COALESCE(?, bank_notes)
    WHERE id = ?
  `).run(status, cleared_at, receiver_face_auth ? 1 : null, bank_notes || null, chequeId);
  
  logAudit(chequeId, status, userId || "SYSTEM", `Status transitioned to ${status}. ${bank_notes ? 'Bank Notes: ' + bank_notes : ''}`);
  broadcast({ type: 'CHEQUE_UPDATED', data: { id: chequeId, status } });
  
  res.json({ status });
});

// Background Scheduler Simulation
setInterval(() => {
  const now = new Date().toISOString().split('T')[0];
  // Only clear cheques that are RECEIVER_ACK and date is reached
  const dueCheques = db.prepare("SELECT * FROM cheques WHERE status = 'RECEIVER_ACK' AND cheque_date <= ?").all(now) as any[];
  
  dueCheques.forEach(cheque => {
    console.log(`[Scheduler] Executing ${cheque.payment_type} ${cheque.id} for ${cheque.amount}`);
    const cleared_at = new Date().toISOString();
    db.prepare("UPDATE cheques SET status = 'CLEARED', cleared_at = ? WHERE id = ?").run(cleared_at, cheque.id);
    logAudit(cheque.id, "CLEARED", "SYSTEM_SCHEDULER", `Automated fund transfer successful. Status: CLEARED.`);
    broadcast({ type: 'CHEQUE_UPDATED', data: { id: cheque.id, status: 'CLEARED' } });
  });
}, 30000);

async function startServer() {
  const PORT = 3000;

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
