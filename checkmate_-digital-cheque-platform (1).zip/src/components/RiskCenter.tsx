import React, { useState, useEffect } from 'react';
import { ShieldAlert, AlertTriangle, ShieldCheck, TrendingUp, Search, Shield, Fingerprint, Globe } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../utils';

export default function RiskCenter() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/risk-stats');
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!stats) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Risk & Fraud Center</h1>
        <p className="text-slate-500 mt-1">Real-time monitoring of transaction integrity and risk scores.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-red-50 rounded-2xl flex items-center justify-center mb-4">
            <ShieldAlert className="w-6 h-6 text-red-600" />
          </div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">High Risk Alerts</p>
          <p className="text-2xl font-bold text-slate-900">{stats.high_risk}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center mb-4">
            <AlertTriangle className="w-6 h-6 text-amber-600" />
          </div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Tamper Attempts</p>
          <p className="text-2xl font-bold text-slate-900">{stats.tampered_count}</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-4">
            <ShieldCheck className="w-6 h-6 text-emerald-600" />
          </div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Avg Risk Score</p>
          <p className="text-2xl font-bold text-slate-900">{Math.round(stats.avg_risk || 0)}/100</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8">
          <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
            <Fingerprint className="w-5 h-5 text-indigo-600" />
            Active Threat Monitoring
          </h3>
          <div className="space-y-6">
            {[
              { label: 'Device Fingerprinting', status: 'Active', color: 'text-emerald-500' },
              { label: 'IP Reputation Analysis', status: 'Active', color: 'text-emerald-500' },
              { label: 'Behavioral Biometrics', status: 'Learning', color: 'text-blue-500' },
              { label: 'Velocity Checks', status: 'Active', color: 'text-emerald-500' },
            ].map((item, i) => (
              <div key={i} className="flex justify-between items-center border-b border-slate-50 pb-4 last:border-0">
                <span className="text-sm text-slate-600 font-medium">{item.label}</span>
                <span className={cn("text-xs font-bold uppercase tracking-widest", item.color)}>{item.status}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="font-bold mb-6 flex items-center gap-2">
              <Globe className="w-5 h-5 text-indigo-400" />
              Global Risk Map
            </h3>
            <div className="aspect-video bg-white/5 rounded-2xl border border-white/10 flex items-center justify-center">
              <p className="text-slate-400 text-sm italic">Risk visualization engine loading...</p>
            </div>
            <div className="mt-6 flex gap-4">
              <div className="flex-1 bg-white/5 p-4 rounded-xl border border-white/10">
                <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Top Risk Origin</p>
                <p className="text-sm font-bold">Mumbai, IN</p>
              </div>
              <div className="flex-1 bg-white/5 p-4 rounded-xl border border-white/10">
                <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Blocked IPs</p>
                <p className="text-sm font-bold">1,242</p>
              </div>
            </div>
          </div>
          <div className="absolute top-[-20%] right-[-20%] w-64 h-64 bg-indigo-600/20 blur-[100px] rounded-full" />
        </div>
      </div>
    </motion.div>
  );
}
