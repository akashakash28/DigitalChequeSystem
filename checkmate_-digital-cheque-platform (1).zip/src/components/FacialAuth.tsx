import React, { useState, useRef, useEffect } from 'react';
import { Camera, ShieldCheck, Loader2, X, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';

interface FacialAuthProps {
  onSuccess: (imageData: string) => void;
  onCancel: () => void;
  title?: string;
}

export default function FacialAuth({ onSuccess, onCancel, title = "Facial Verification" }: FacialAuthProps) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    startCamera();
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startCamera = async () => {
    setError(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      setStream(s);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
      }
    } catch (err) {
      console.error("Camera access denied", err);
      setError("Camera access denied. Please check your browser permissions.");
    }
  };

  const capture = () => {
    if (videoRef.current && canvasRef.current) {
      setLoading(true);
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        
        // Simulate AI processing
        setTimeout(() => {
          setLoading(false);
          setSuccess(true);
          setTimeout(() => {
            onSuccess(dataUrl);
          }, 1500);
        }, 2000);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-2xl overflow-hidden max-w-md w-full"
      >
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-900">{title}</h3>
          </div>
          <button onClick={onCancel} className="p-2 hover:bg-slate-100 rounded-full">
            <X className="w-5 h-5 text-slate-400" />
          </button>
        </div>

        <div className="p-8 flex flex-col items-center">
          {error && (
            <div className="w-full p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-sm font-medium mb-6">
              <AlertCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          <div className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-indigo-100 mb-8 bg-slate-100">
            {!success ? (
              <>
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />
                <div className="absolute inset-0 border-[20px] border-indigo-600/10 rounded-full pointer-events-none" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-48 h-48 border-2 border-dashed border-white/50 rounded-full" />
                </div>
              </>
            ) : (
              <div className="w-full h-full bg-emerald-50 flex items-center justify-center flex-col text-emerald-600">
                <CheckCircle2 className="w-16 h-16 mb-2 animate-bounce" />
                <p className="font-bold">Identity Verified</p>
              </div>
            )}

            {loading && (
              <div className="absolute inset-0 bg-indigo-600/20 backdrop-blur-sm flex items-center justify-center">
                <Loader2 className="w-10 h-10 text-white animate-spin" />
              </div>
            )}
          </div>

          <p className="text-center text-slate-500 text-sm mb-8">
            Position your face within the circle and ensure good lighting for biometric verification.
          </p>

          {!success && (
            <button 
              onClick={capture}
              disabled={loading}
              className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 disabled:opacity-50 transition-all"
            >
              {loading ? "Analyzing Biometrics..." : "Verify Identity"}
            </button>
          )}
        </div>
        <canvas ref={canvasRef} className="hidden" />
      </motion.div>
    </div>
  );
}
