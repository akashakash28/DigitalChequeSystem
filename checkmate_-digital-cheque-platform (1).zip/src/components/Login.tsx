import React, { useState } from 'react';
import { Shield, User, Building2, Lock, ArrowRight, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../utils';

export type UserRole = 'USER' | 'BANK_ADMIN';

interface LoginProps {
  onLogin: (role: UserRole) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [role, setRole] = useState<UserRole>('USER');
  const [loading, setLoading] = useState(false);

  const handleLogin = () => {
    setLoading(true);
    setTimeout(() => {
      onLogin(role);
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold italic text-2xl mx-auto mb-4 shadow-xl shadow-indigo-100">
            CM
          </div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">CheckMate</h1>
          <p className="text-slate-500 mt-2 font-medium">Secure Digital Transaction Platform</p>
        </div>

        <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/50 border border-slate-100 p-10">
          <h2 className="text-xl font-bold text-slate-900 mb-8 text-center">Select Portal Access</h2>
          
          <div className="space-y-4 mb-10">
            <button 
              onClick={() => setRole('USER')}
              className={cn(
                "w-full p-6 rounded-3xl border-2 transition-all flex items-center gap-4 text-left group",
                role === 'USER' 
                  ? "border-indigo-600 bg-indigo-50/50" 
                  : "border-slate-100 hover:border-slate-200 bg-white"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                role === 'USER' ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-400 group-hover:bg-slate-200"
              )}>
                <User className="w-6 h-6" />
              </div>
              <div>
                <p className={cn("font-bold", role === 'USER' ? "text-indigo-900" : "text-slate-700")}>Customer Portal</p>
                <p className="text-xs text-slate-400 mt-0.5">Issue and manage personal cheques</p>
              </div>
            </button>

            <button 
              onClick={() => setRole('BANK_ADMIN')}
              className={cn(
                "w-full p-6 rounded-3xl border-2 transition-all flex items-center gap-4 text-left group",
                role === 'BANK_ADMIN' 
                  ? "border-slate-900 bg-slate-50" 
                  : "border-slate-100 hover:border-slate-200 bg-white"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                role === 'BANK_ADMIN' ? "bg-slate-900 text-white" : "bg-slate-100 text-slate-400 group-hover:bg-slate-200"
              )}>
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <p className={cn("font-bold", role === 'BANK_ADMIN' ? "text-slate-900" : "text-slate-700")}>Bank Review Portal</p>
                <p className="text-xs text-slate-400 mt-0.5">Official clearing house operations</p>
              </div>
            </button>
          </div>

          <button 
            onClick={handleLogin}
            disabled={loading}
            className={cn(
              "w-full py-5 rounded-2xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2",
              role === 'USER' ? "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100" : "bg-slate-900 hover:bg-slate-800 shadow-slate-200"
            )}
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                Enter Platform
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>

        <div className="mt-8 flex items-center justify-center gap-2 text-slate-400">
          <Shield className="w-4 h-4" />
          <span className="text-xs font-bold uppercase tracking-widest">Bank-Grade 256-bit Encryption</span>
        </div>
      </motion.div>
    </div>
  );
}
