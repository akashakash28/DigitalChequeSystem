import React, { useState, useRef } from 'react';
import { Camera, Upload, X, Loader2, CheckCircle2, ShieldCheck, AlertCircle, Lock, Fingerprint } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { extractChequeData } from '../services/geminiService';
import { cn } from '../utils';
import FacialAuth from './FacialAuth';

interface ChequeFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export default function ChequeCreator({ onSuccess, onCancel }: ChequeFormProps) {
  const [mode, setMode] = useState<'manual' | 'camera' | null>(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [showFaceAuth, setShowFaceAuth] = useState(false);
  const [faceVerified, setFaceVerified] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    payee: '',
    amount: '',
    amount_words: '',
    purpose: '',
    cheque_date: new Date().toISOString().split('T')[0],
    payment_type: 'CHEQUE',
    password: '',
    secret_key: '',
  });

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    setCameraError(null);
    setMode('camera');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera access denied", err);
      setCameraError("Camera access denied. Please ensure you have granted permission in your browser and that no other app is using the camera.");
      setTimeout(() => setMode(null), 3000);
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvasRef.current.toDataURL('image/jpeg');
        setPreview(dataUrl);
        processOCR(dataUrl);
        
        // Stop camera
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    }
  };

  const processOCR = async (base64: string) => {
    setLoading(true);
    try {
      const data = await extractChequeData(base64);
      setFormData(prev => ({
        ...prev,
        payee: data.payee || '',
        amount: data.amount?.toString() || '',
        amount_words: data.amount_words || '',
        purpose: data.purpose || '',
        cheque_date: data.cheque_date || new Date().toISOString().split('T')[0],
      }));
    } catch (err) {
      console.error("OCR failed", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!faceVerified) {
      setShowFaceAuth(true);
      return;
    }
    submitCheque();
  };

  const submitCheque = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/cheques', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          amount: parseFloat(formData.amount),
          image_data: preview,
          sender_face_auth: true
        }),
      });
      if (res.ok) {
        onSuccess();
      } else {
        const errorData = await res.json();
        setCameraError(errorData.error || "Submission failed");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200"
    >
      <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Issue Digital Transaction</h2>
          <p className="text-slate-500 text-sm mt-1">Create a new secure payment authorization</p>
        </div>
        <button onClick={onCancel} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
          <X className="w-6 h-6 text-slate-400" />
        </button>
      </div>

      <div className="p-8">
        {!mode ? (
          <div className="grid grid-cols-2 gap-6">
            <button 
              onClick={() => setMode('manual')}
              className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-200 rounded-2xl hover:border-indigo-500 hover:bg-indigo-50 transition-all group"
            >
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Upload className="w-6 h-6 text-indigo-600" />
              </div>
              <span className="font-semibold text-slate-700">Manual Entry</span>
              <span className="text-xs text-slate-400 mt-1">Type details manually</span>
            </button>
            <button 
              onClick={startCamera}
              className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-200 rounded-2xl hover:border-emerald-500 hover:bg-emerald-50 transition-all group"
            >
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Camera className="w-6 h-6 text-emerald-600" />
              </div>
              <span className="font-semibold text-slate-700">Scan Cheque</span>
              <span className="text-xs text-slate-400 mt-1">Use camera + OCR</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {cameraError && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600 text-sm font-medium animate-shake">
                <AlertCircle className="w-5 h-5" />
                {cameraError}
              </div>
            )}
            {mode === 'camera' && !preview && !cameraError && (
              <div className="relative rounded-2xl overflow-hidden bg-black aspect-video mb-6">
                <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                <button 
                  type="button"
                  onClick={captureImage}
                  className="absolute bottom-6 left-1/2 -translate-x-1/2 w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                >
                  <div className="w-12 h-12 border-4 border-slate-200 rounded-full" />
                </button>
              </div>
            )}

            {preview && (
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 aspect-video mb-6">
                <img src={preview} className="w-full h-full object-cover" alt="Cheque Preview" />
                <button 
                  type="button"
                  onClick={() => { setPreview(null); setMode('camera'); startCamera(); }}
                  className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70"
                >
                  <X className="w-4 h-4" />
                </button>
                {loading && (
                  <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex flex-col items-center justify-center">
                    <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-2" />
                    <p className="text-sm font-medium text-slate-700">Extracting details via AI...</p>
                  </div>
                )}
              </div>
            )}

            <div className="grid grid-cols-2 gap-6">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Payment Type</label>
                <div className="flex gap-4">
                  {['CHEQUE', 'NEFT', 'RTGS'].map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => setFormData({...formData, payment_type: type})}
                      className={cn(
                        "flex-1 py-3 rounded-xl border font-bold transition-all",
                        formData.payment_type === type 
                          ? "bg-indigo-600 border-indigo-600 text-white shadow-md" 
                          : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                      )}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Payee Name</label>
                <input 
                  required
                  value={formData.payee}
                  onChange={e => setFormData({...formData, payee: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                  placeholder="Who are you paying?"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Amount (INR)</label>
                <input 
                  required
                  type="number"
                  value={formData.amount}
                  onChange={e => setFormData({...formData, amount: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Cheque Date</label>
                <input 
                  required
                  type="date"
                  value={formData.cheque_date}
                  onChange={e => setFormData({...formData, cheque_date: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Amount in Words</label>
                <input 
                  value={formData.amount_words}
                  onChange={e => setFormData({...formData, amount_words: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                  placeholder="Rupees Ten Thousand Only"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Purpose / Memo</label>
                <input 
                  value={formData.purpose}
                  onChange={e => setFormData({...formData, purpose: e.target.value})}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                  placeholder="What is this for?"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Account Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="password"
                    required
                    value={formData.password}
                    onChange={e => setFormData({...formData, password: e.target.value})}
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
                    placeholder="••••••••"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Secret Authorization Key (PIN)</label>
                <div className="relative">
                  <Fingerprint className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="password"
                    required
                    maxLength={4}
                    value={formData.secret_key}
                    onChange={e => setFormData({...formData, secret_key: e.target.value})}
                    className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none font-mono tracking-[0.5em]"
                    placeholder="0000"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1 italic">Demo PIN: 1234</p>
              </div>
            </div>

            <div className="pt-6 flex gap-4">
              <button 
                type="button"
                onClick={() => setMode(null)}
                className="flex-1 px-6 py-4 rounded-xl border border-slate-200 font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Back
              </button>
              <button 
                disabled={loading}
                className="flex-[2] px-6 py-4 rounded-xl bg-indigo-600 text-white font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (faceVerified ? <CheckCircle2 className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />)}
                {faceVerified ? "Issue Transaction" : "Verify & Issue"}
              </button>
            </div>
          </form>
        )}
      </div>
      <canvas ref={canvasRef} className="hidden" />

      <AnimatePresence>
        {showFaceAuth && (
          <FacialAuth 
            title="Sender Biometric Verification"
            onSuccess={() => {
              setFaceVerified(true);
              setShowFaceAuth(false);
              // Small delay to show success state in FacialAuth before submitting
              setTimeout(submitCheque, 500);
            }}
            onCancel={() => setShowFaceAuth(false)}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
}
