import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search, 
  Filter, 
  ChevronRight, 
  ShieldCheck, 
  AlertTriangle,
  FileText,
  MessageSquare,
  Fingerprint
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, formatCurrency, formatDate, CHEQUE_STATES } from '../utils';

export default function BankPortal() {
  const [cheques, setCheques] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [bankNotes, setBankNotes] = useState('');
  const [filter, setFilter] = useState('SUBMITTED');

  useEffect(() => {
    fetchCheques();
  }, []);

  const fetchCheques = async () => {
    try {
      const res = await fetch('/api/cheques');
      const data = await res.json();
      setCheques(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAction = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/cheques/${id}/transition`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          status, 
          userId: "BANK_ADMIN",
          bank_notes: bankNotes 
        }),
      });
      if (res.ok) {
        fetchCheques();
        setSelectedId(null);
        setBankNotes('');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const selectedCheque = cheques.find(c => c.id === selectedId);
  const filteredCheques = cheques.filter(c => c.status === filter);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      <div className="flex justify-between items-end">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white shadow-xl">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Bank Review Portal</h1>
              <p className="text-slate-500 text-sm">Official clearing house interface for transaction verification.</p>
            </div>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="bg-white px-4 py-2 rounded-xl border border-slate-200 flex items-center gap-3">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">Clearing System Online</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* List Section */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/30">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-400" />
                Review Queue
              </h3>
              <div className="flex gap-2">
                {['SUBMITTED', 'BANK_VERIFIED', 'RECEIVER_ACK', 'CLEARED', 'REJECTED'].map(f => (
                  <button 
                    key={f}
                    onClick={() => setFilter(f)}
                    className={cn(
                      "px-4 py-1.5 rounded-full text-[10px] font-bold transition-all uppercase tracking-wider",
                      filter === f ? "bg-slate-900 text-white shadow-md" : "text-slate-500 hover:bg-slate-100"
                    )}
                  >
                    {f.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            <div className="divide-y divide-slate-100">
              {filteredCheques.map((c) => (
                <div 
                  key={c.id}
                  onClick={() => setSelectedId(c.id)}
                  className={cn(
                    "p-6 flex items-center justify-between hover:bg-slate-50/80 cursor-pointer transition-all",
                    selectedId === c.id ? "bg-indigo-50/30 border-l-4 border-indigo-600" : "border-l-4 border-transparent"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center transition-colors",
                      selectedId === c.id ? "bg-white text-indigo-600 shadow-sm" : "bg-slate-100 text-slate-400"
                    )}>
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{c.payee}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[9px] font-bold bg-slate-200 text-slate-600 px-1.5 rounded uppercase">{c.payment_type}</span>
                        <span className="text-xs text-slate-400 font-mono">#{c.id.slice(0, 8)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-slate-900">{formatCurrency(c.amount)}</p>
                    <div className="flex items-center justify-end gap-1.5 mt-1">
                      <Clock className="w-3 h-3 text-slate-300" />
                      <p className="text-[10px] text-slate-400 font-bold uppercase">{formatDate(c.cheque_date)}</p>
                    </div>
                  </div>
                </div>
              ))}
              {filteredCheques.length === 0 && (
                <div className="p-24 text-center">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-slate-200" />
                  </div>
                  <p className="text-slate-400 font-medium">No transactions found in this queue.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Detail/Action Section */}
        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {selectedCheque ? (
              <motion.div 
                key={selectedCheque.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-3xl border border-slate-200 shadow-xl p-8 space-y-8 sticky top-8"
              >
                <div className="pb-6 border-b border-slate-100">
                  <h3 className="text-xl font-bold text-slate-900 mb-6">Verification Checklist</h3>
                  <div className="space-y-5">
                    <div className="flex justify-between items-center p-3 bg-slate-50 rounded-xl">
                      <span className="text-xs font-bold text-slate-500 uppercase">Risk Score</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                          <div className={cn("h-full", selectedCheque.risk_score > 50 ? "bg-red-500" : "bg-emerald-500")} style={{ width: `${selectedCheque.risk_score}%` }} />
                        </div>
                        <span className={cn("text-sm font-bold", selectedCheque.risk_score > 50 ? "text-red-600" : "text-emerald-600")}>
                          {selectedCheque.risk_score}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center px-1">
                      <div className="flex items-center gap-2">
                        <Fingerprint className="w-4 h-4 text-slate-400" />
                        <span className="text-xs text-slate-600 font-medium">Sender Biometrics</span>
                      </div>
                      {selectedCheque.sender_face_auth ? (
                        <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold uppercase">Verified</span>
                      ) : (
                        <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold uppercase">Skipped</span>
                      )}
                    </div>

                    <div className="flex justify-between items-center px-1">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-slate-400" />
                        <span className="text-xs text-slate-600 font-medium">Receiver Biometrics</span>
                      </div>
                      {selectedCheque.receiver_face_auth ? (
                        <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold uppercase">Verified</span>
                      ) : (
                        <span className="text-[10px] bg-slate-100 text-slate-400 px-2 py-0.5 rounded-full font-bold uppercase">Pending</span>
                      )}
                    </div>

                    <div className="flex justify-between items-center px-1">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-slate-400" />
                        <span className="text-xs text-slate-600 font-medium">Integrity Check</span>
                      </div>
                      {selectedCheque.tampered ? (
                        <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-bold uppercase">FAILED</span>
                      ) : (
                        <span className="text-[10px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold uppercase">PASSED</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Reviewer Decision Notes</label>
                  <textarea 
                    value={bankNotes}
                    onChange={e => setBankNotes(e.target.value)}
                    className="w-full h-28 p-4 rounded-2xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-slate-900 outline-none text-sm transition-all"
                    placeholder="Enter approval/rejection notes for the audit trail..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {selectedCheque.status === 'SUBMITTED' && (
                    <>
                      <button 
                        onClick={() => handleAction(selectedCheque.id, 'BANK_VERIFIED')}
                        className="col-span-2 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 flex flex-col items-center justify-center gap-1 transition-all active:scale-95"
                      >
                        <ShieldCheck className="w-5 h-5" />
                        <span className="text-xs">Approve (Bank Verified)</span>
                      </button>
                      <button 
                        onClick={() => handleAction(selectedCheque.id, 'FLAGGED')}
                        className="col-span-2 py-3 bg-amber-50 text-amber-600 border border-amber-100 rounded-2xl font-bold hover:bg-amber-100 flex items-center justify-center gap-2 transition-all"
                      >
                        <AlertTriangle className="w-4 h-4" />
                        <span className="text-xs">Flag for Review</span>
                      </button>
                    </>
                  )}
                  {selectedCheque.status === 'BANK_VERIFIED' && (
                    <button 
                      onClick={() => handleAction(selectedCheque.id, 'RECEIVER_ACK')}
                      className="col-span-2 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 shadow-lg shadow-blue-100 flex flex-col items-center justify-center gap-1 transition-all active:scale-95"
                    >
                      <Building2 className="w-5 h-5" />
                      <span className="text-xs">Receiver Bank Ack</span>
                    </button>
                  )}
                  {['SUBMITTED', 'BANK_VERIFIED', 'RECEIVER_ACK'].includes(selectedCheque.status) && (
                    <button 
                      onClick={() => handleAction(selectedCheque.id, 'REJECTED')}
                      className="col-span-2 py-4 bg-red-50 text-red-600 border border-red-100 rounded-2xl font-bold hover:bg-red-100 flex flex-col items-center justify-center gap-1 transition-all active:scale-95"
                    >
                      <XCircle className="w-5 h-5" />
                      <span className="text-xs">Reject Transaction</span>
                    </button>
                  )}
                </div>
              </motion.div>
            ) : (
              <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 p-12 text-center text-slate-400 h-[500px] flex flex-col items-center justify-center">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                  <Building2 className="w-10 h-10 text-slate-200" />
                </div>
                <h4 className="text-slate-900 font-bold mb-2">No Transaction Selected</h4>
                <p className="text-sm max-w-[200px] mx-auto">Select a transaction from the queue to begin the official review process.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
