import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Shield, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  History, 
  Lock, 
  ArrowRight, 
  X,
  FileText,
  ShieldAlert,
  ShieldCheck,
  Building2
} from 'lucide-react';
import { cn, formatCurrency, formatDate, CHEQUE_STATES } from '../utils';
import FacialAuth from './FacialAuth';

interface ChequeDetailProps {
  id: string;
  onClose: () => void;
  onUpdate: () => void;
}

export default function ChequeDetail({ id, onClose, onUpdate }: ChequeDetailProps) {
  const [cheque, setCheque] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [authStep, setAuthStep] = useState<'view' | 'face' | 'success'>('view');

  useEffect(() => {
    fetchCheque();
  }, [id]);

  const fetchCheque = async () => {
    try {
      const res = await fetch(`/api/cheques/${id}`);
      const data = await res.json();
      setCheque(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleTransition = async (status: string, faceAuth: boolean = false) => {
    try {
      const res = await fetch(`/api/cheques/${id}/transition`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          status, 
          userId: "RECEIVER_USER",
          receiver_face_auth: faceAuth
        }),
      });
      if (res.ok) {
        fetchCheque();
        onUpdate();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading || !cheque) return null;

  const state = CHEQUE_STATES[cheque.status as keyof typeof CHEQUE_STATES] || CHEQUE_STATES.UNKNOWN;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-4xl max-h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div className="flex items-center gap-4">
            <div className={cn("px-3 py-1 rounded-full text-xs font-bold border", state.color)}>
              {state.label}
            </div>
            <span className="text-slate-400 font-mono text-xs">ID: {cheque.id.slice(0, 8)}...</span>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: Cheque Visual & Details */}
            <div className="lg:col-span-2 space-y-8">
              {/* Virtual Cheque Card */}
              <div className="cheque-gradient border border-slate-200 rounded-3xl p-8 shadow-sm relative overflow-hidden">
                {cheque.tampered && (
                  <div className="absolute inset-0 bg-red-500/10 backdrop-blur-[2px] flex items-center justify-center z-10">
                    <div className="bg-red-600 text-white px-6 py-2 rounded-full font-bold flex items-center gap-2 shadow-lg rotate-[-5deg]">
                      <ShieldAlert className="w-5 h-5" />
                      TAMPERED / INVALID
                    </div>
                  </div>
                )}
                
                <div className="flex justify-between items-start mb-12">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold italic">CM</div>
                    <div>
                      <h3 className="font-bold text-slate-900 leading-tight">CheckMate</h3>
                      <p className="text-[10px] text-slate-500 uppercase tracking-widest">Digital Reserve Bank</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Date</p>
                    <p className="font-mono text-lg text-slate-800">{formatDate(cheque.cheque_date)}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="flex items-end gap-4 border-b border-slate-200 pb-2">
                    <span className="text-xs font-serif italic text-slate-400 whitespace-nowrap">Pay to the order of</span>
                    <span className="flex-1 font-serif text-2xl text-slate-900 border-b border-dotted border-slate-300">{cheque.payee}</span>
                  </div>
                  
                  <div className="flex items-end gap-4 border-b border-slate-200 pb-2">
                    <span className="text-xs font-serif italic text-slate-400 whitespace-nowrap">The sum of</span>
                    <span className="flex-1 font-serif text-lg text-slate-700 italic">{cheque.amount_words || "---"}</span>
                    <div className="bg-slate-100 px-4 py-2 rounded-lg border border-slate-200 min-w-[140px] text-right">
                      <span className="text-xl font-bold text-slate-900">{formatCurrency(cheque.amount)}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-12 flex justify-between items-end">
                  <div className="space-y-1">
                    <p className="text-[10px] text-slate-400 uppercase font-bold">Purpose</p>
                    <p className="text-sm text-slate-600">{cheque.purpose || "General Payment"}</p>
                  </div>
                  <div className="text-center">
                    {cheque.hash ? (
                      <div className="flex flex-col items-center gap-1">
                        <Lock className="w-5 h-5 text-emerald-500" />
                        <p className="text-[8px] font-mono text-slate-400 max-w-[120px] truncate">{cheque.hash}</p>
                        <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-tighter">Digitally Signed</p>
                      </div>
                    ) : (
                      <div className="border-t border-slate-300 pt-2 px-8">
                        <p className="text-[10px] text-slate-400 uppercase italic">Signature Required</p>
                      </div>
                    )}
                  </div>
                </div>

                {cheque.bank_notes && (
                  <div className="mt-8 p-4 bg-amber-50 rounded-xl border border-amber-100">
                    <p className="text-[10px] text-amber-600 uppercase font-bold mb-1 flex items-center gap-1">
                      <Building2 className="w-3 h-3" />
                      Bank Reviewer Notes
                    </p>
                    <p className="text-sm text-amber-900 italic">"{cheque.bank_notes}"</p>
                  </div>
                )}
              </div>

              {/* Action Panel */}
              <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200">
                <h4 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Shield className="w-4 h-4 text-indigo-600" />
                  Security & Lifecycle Actions
                </h4>
                
                <div className="flex flex-wrap gap-4">
                  {cheque.status === 'SUBMITTED' && (
                    <button 
                      onClick={() => handleTransition('CANCELLED')}
                      className="px-6 py-3 bg-white text-slate-600 border border-slate-200 rounded-xl font-bold hover:bg-slate-50 transition-all"
                    >
                      Cancel Transaction
                    </button>
                  )}
                  
                  {['BANK_VERIFIED', 'RECEIVER_ACK'].includes(cheque.status) && (
                    <div className="flex items-center gap-2 text-indigo-600 bg-indigo-50 px-4 py-2 rounded-xl border border-indigo-100">
                      <Clock className="w-4 h-4 animate-pulse" />
                      <span className="text-xs font-bold uppercase">Processing in Clearing House</span>
                    </div>
                  )}

                  {cheque.status === 'CLEARED' && (
                    <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-100">
                      <CheckCircle2 className="w-4 h-4" />
                      <span className="text-xs font-bold uppercase">Funds Disbursed</span>
                    </div>
                  )}
                </div>

                <AnimatePresence>
                </AnimatePresence>
              </div>
            </div>

            {/* Right Column: Audit Trail & Risk */}
            <div className="space-y-6">
              <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200">
                <h4 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-600" />
                  Risk Assessment
                </h4>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-slate-500">Risk Score</span>
                    <span className={cn(
                      "text-lg font-bold",
                      cheque.risk_score > 50 ? "text-red-600" : "text-emerald-600"
                    )}>{cheque.risk_score}/100</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div 
                      className={cn(
                        "h-full transition-all duration-1000",
                        cheque.risk_score > 50 ? "bg-red-500" : "bg-emerald-500"
                      )}
                      style={{ width: `${cheque.risk_score}%` }}
                    />
                  </div>
                  <ul className="text-[10px] space-y-2 text-slate-500">
                    <li className="flex items-center gap-2">
                      <ShieldCheck className={cn("w-3 h-3", cheque.sender_face_auth ? "text-emerald-500" : "text-slate-300")} />
                      Sender Biometrics: {cheque.sender_face_auth ? "Verified" : "Skipped"}
                    </li>
                    <li className="flex items-center gap-2">
                      <ShieldCheck className={cn("w-3 h-3", cheque.receiver_face_auth ? "text-emerald-500" : "text-slate-300")} />
                      Receiver Biometrics: {cheque.receiver_face_auth ? "Verified" : "Pending"}
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      Device Fingerprint Verified
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                      IP Reputation: Clean
                    </li>
                    {cheque.amount > 100000 && (
                      <li className="flex items-center gap-2">
                        <AlertTriangle className="w-3 h-3 text-amber-500" />
                        High Value Transaction
                      </li>
                    )}
                  </ul>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-slate-200 flex-1">
                <h4 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <History className="w-4 h-4 text-slate-400" />
                  Immutable Audit Log
                </h4>
                <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                  {cheque.logs?.map((log: any) => (
                    <div key={log.id} className="relative pl-6 pb-4 border-l border-slate-100 last:pb-0">
                      <div className="absolute left-[-5px] top-1 w-2 h-2 rounded-full bg-slate-300" />
                      <p className="text-[10px] font-bold text-slate-400 uppercase">{formatDate(log.timestamp)}</p>
                      <p className="text-xs font-bold text-slate-800">{log.action}</p>
                      <p className="text-[10px] text-slate-500 mt-1">{log.details}</p>
                      <p className="text-[8px] text-slate-400 mt-1 font-mono">User: {log.user_id}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {authStep === 'face' && (
          <FacialAuth 
            title="Receiver Biometric Verification"
            onSuccess={() => {
              setAuthStep('view');
              handleTransition('ACCEPTED', true);
            }}
            onCancel={() => setAuthStep('view')}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
