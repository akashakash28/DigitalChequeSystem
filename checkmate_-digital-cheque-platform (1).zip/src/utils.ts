import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
  }).format(amount);
}

export function formatDate(dateString: string) {
  return new Date(dateString).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export const CHEQUE_STATES = {
  SUBMITTED: { label: "Submitted", color: "bg-amber-100 text-amber-700 border-amber-200" },
  BANK_VERIFIED: { label: "Bank Verified", color: "bg-blue-100 text-blue-700 border-blue-200" },
  RECEIVER_ACK: { label: "Receiver Ack", color: "bg-indigo-100 text-indigo-700 border-indigo-200" },
  CLEARED: { label: "Cleared", color: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  REJECTED: { label: "Rejected", color: "bg-red-100 text-red-700 border-red-200" },
  CANCELLED: { label: "Cancelled", color: "bg-slate-100 text-slate-700 border-slate-200" },
  FLAGGED: { label: "Flagged", color: "bg-orange-100 text-orange-700 border-orange-200" },
  UNKNOWN: { label: "Unknown", color: "bg-slate-100 text-slate-400 border-slate-200" },
};
