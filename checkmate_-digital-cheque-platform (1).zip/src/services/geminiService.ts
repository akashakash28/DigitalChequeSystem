import { GoogleGenAI, Type } from "@google/genai";

export async function extractChequeData(base64Image: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(",")[1],
            },
          },
          {
            text: "Extract cheque details from this image. Return the payee name, amount as a number, purpose (if any), and date (YYYY-MM-DD). Also provide the amount in words.",
          },
        ],
      },
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          payee: { type: Type.STRING },
          amount: { type: Type.NUMBER },
          amount_words: { type: Type.STRING },
          purpose: { type: Type.STRING },
          cheque_date: { type: Type.STRING },
        },
        required: ["payee", "amount", "cheque_date"],
      },
    },
  });

  return JSON.parse(response.text);
}
