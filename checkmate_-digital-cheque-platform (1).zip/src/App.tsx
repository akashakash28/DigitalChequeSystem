import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  Plus, 
  Search, 
  Bell, 
  ShieldCheck, 
  TrendingUp, 
  Clock, 
  ArrowUpRight,
  Filter,
  MoreVertical,
  ChevronRight,
  Activity,
  ShieldAlert,
  CheckCircle2,
  FileText,
  AlertCircle,
  Building2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ChequeCreator from './components/ChequeCreator';
import ChequeDetail from './components/ChequeDetail';
import AuditLogs from './components/AuditLogs';
import RiskCenter from './components/RiskCenter';
import BankPortal from './components/BankPortal';
import Login, { UserRole } from './components/Login';
import { cn, formatCurrency, formatDate, CHEQUE_STATES } from './utils';

type View = 'DASHBOARD' | 'AUDIT_LOGS' | 'RISK_CENTER' | 'BANK_PORTAL';

export default function App() {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [currentView, setCurrentView] = useState<View>('DASHBOARD');
  const [cheques, setCheques] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreator, setShowCreator] = useState(false);
  const [selectedChequeId, setSelectedChequeId] = useState<string | null>(null);
  const [filter, setFilter] = useState('ALL');
  const [notifications, setNotifications] = useState<any[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    fetchCheques();
    setupWebSocket();
    return () => wsRef.current?.close();
  }, []);

  const setupWebSocket = () => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);
    
    ws.onmessage = (event) => {
      const { type, data } = JSON.parse(event.data);
      
      if (type === 'CHEQUE_CREATED' || type === 'CHEQUE_UPDATED') {
        fetchCheques();
        addNotification(`Transaction ${type === 'CHEQUE_CREATED' ? 'Created' : 'Updated'}: ${data.id.slice(0, 8)}`);
      }
      
      if (type === 'RISK_ALERT') {
        addNotification(`RISK ALERT: Tamper detected on ${data.cheque_id.slice(0, 8)}`, 'error');
      }
    };

    ws.onclose = () => setTimeout(setupWebSocket, 3000);
    wsRef.current = ws;
  };

  const addNotification = (message: string, type: 'info' | 'error' = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [{ id, message, type }, ...prev].slice(0, 5));
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  const fetchCheques = async () => {
    try {
      const res = await fetch('/api/cheques');
      const data = await res.json();
      setCheques(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getSLAStatus = (cheque: any) => {
    if (cheque.status === 'CLEARED') {
      const cleared = new Date(cheque.cleared_at);
      const deadline = new Date(cheque.sla_deadline);
      return cleared <= deadline ? 'SLA_MET' : 'SLA_BREACHED';
    }
    const now = new Date();
    const deadline = new Date(cheque.sla_deadline);
    return now <= deadline ? 'SLA_OK' : 'SLA_BREACHED';
  };

  const stats = {
    total: cheques.length,
    cleared: cheques.filter(c => c.status === 'CLEARED').length,
    pending: cheques.filter(c => ['SUBMITTED', 'BANK_VERIFIED', 'RECEIVER_ACK'].includes(c.status)).length,
    volume: cheques.reduce((acc, c) => acc + c.amount, 0),
  };

  const filteredCheques = filter === 'ALL' 
    ? cheques 
    : cheques.filter(c => c.status === filter);

  if (!userRole) {
    return <Login onLogin={(role) => {
      setUserRole(role);
      setCurrentView(role === 'BANK_ADMIN' ? 'BANK_PORTAL' : 'DASHBOARD');
    }} />;
  }

  return (
    <div className="min-h-screen flex bg-[#F8F9FA]">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col hidden lg:flex">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">CheckMate</span>
          </div>

          <nav className="space-y-2">
            {userRole === 'USER' && (
              <button 
                onClick={() => setCurrentView('DASHBOARD')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all",
                  currentView === 'DASHBOARD' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
                )}
              >
                <LayoutDashboard className="w-5 h-5" />
                Dashboard
              </button>
            )}
            <button 
              onClick={() => setCurrentView('AUDIT_LOGS')}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all",
                currentView === 'AUDIT_LOGS' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
              )}
            >
              <Activity className="w-5 h-5" />
              Audit Logs
            </button>
            <button 
              onClick={() => setCurrentView('RISK_CENTER')}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all",
                currentView === 'RISK_CENTER' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
              )}
            >
              <ShieldAlert className="w-5 h-5" />
              Risk Center
            </button>
            {userRole === 'BANK_ADMIN' && (
              <button 
                onClick={() => setCurrentView('BANK_PORTAL')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all",
                  currentView === 'BANK_PORTAL' ? "bg-slate-900 text-white shadow-lg" : "text-slate-500 hover:bg-slate-50"
                )}
              >
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", currentView === 'BANK_PORTAL' ? "bg-white/20" : "bg-slate-100")}>
                  <Building2 className={cn("w-4 h-4", currentView === 'BANK_PORTAL' ? "text-white" : "text-slate-500")} />
                </div>
                Bank Portal
              </button>
            )}
          </nav>
        </div>

        <div className="mt-auto p-6">
          <div className="bg-slate-900 rounded-2xl p-4 text-white">
            <p className="text-xs text-slate-400 mb-1">Current Balance</p>
            <p className="text-xl font-bold mb-4">₹ 12,45,000.00</p>
            <button className="w-full py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold transition-all">
              Top Up Account
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center gap-4 bg-slate-50 px-4 py-2 rounded-xl border border-slate-200 w-96">
            <Search className="w-4 h-4 text-slate-400" />
            <input 
              placeholder="Search cheques, payees, or IDs..." 
              className="bg-transparent border-none outline-none text-sm w-full"
            />
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-400 hover:bg-slate-50 rounded-full relative">
              <Bell className="w-5 h-5" />
              {notifications.length > 0 && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white" />
              )}
            </button>
            <div className="h-8 w-px bg-slate-200 mx-2" />
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-sm font-bold text-slate-900">{userRole === 'BANK_ADMIN' ? 'Bank Officer' : 'Customer Account'}</p>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{userRole === 'BANK_ADMIN' ? 'Official Access' : 'Verified Entity'}</p>
              </div>
              <div className="w-10 h-10 bg-slate-200 rounded-full border-2 border-white shadow-sm overflow-hidden">
                <img src={`https://picsum.photos/seed/${userRole}/100/100`} alt="Avatar" referrerPolicy="no-referrer" />
              </div>
              <button 
                onClick={() => setUserRole(null)}
                className="ml-2 p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors"
                title="Logout"
              >
                <ArrowUpRight className="w-4 h-4 rotate-45" />
              </button>
            </div>
          </div>
        </header>

        {/* View Content */}
        <div className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            {currentView === 'DASHBOARD' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="space-y-8"
              >
                {/* Hero Section */}
                <div className="flex justify-between items-end">
                  <div>
                    <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Financial Overview</h1>
                    <p className="text-slate-500 mt-1">Manage your digital cheque lifecycle and authorizations.</p>
                  </div>
                  <button 
                    onClick={() => setShowCreator(true)}
                    className="px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-indigo-100 hover:scale-105 active:scale-95 transition-all"
                  >
                    <Plus className="w-5 h-5" />
                    Issue New Transaction
                  </button>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Volume', value: formatCurrency(stats.volume), icon: TrendingUp, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                    { label: 'Active Cheques', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
                    { label: 'Cleared Today', value: stats.cleared, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                    { label: 'Security Score', value: '98%', icon: ShieldCheck, color: 'text-blue-600', bg: 'bg-blue-50' },
                  ].map((stat, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm"
                    >
                      <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center mb-4", stat.bg)}>
                        <stat.icon className={cn("w-6 h-6", stat.color)} />
                      </div>
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">{stat.label}</p>
                      <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                    </motion.div>
                  ))}
                </div>

                {/* Cheque List */}
                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-bold text-slate-900">Recent Transactions</h3>
                    <div className="flex gap-2">
                      {['ALL', 'SUBMITTED', 'BANK_VERIFIED', 'RECEIVER_ACK', 'CLEARED'].map(f => (
                        <button 
                          key={f}
                          onClick={() => setFilter(f)}
                          className={cn(
                            "px-4 py-1.5 rounded-full text-[10px] font-bold transition-all uppercase tracking-wider",
                            filter === f ? "bg-slate-900 text-white" : "text-slate-500 hover:bg-slate-50"
                          )}
                        >
                          {f.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="bg-slate-50/50 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          <th className="px-8 py-4">Details</th>
                          <th className="px-8 py-4">Status</th>
                          <th className="px-8 py-4">SLA Status</th>
                          <th className="px-8 py-4">Amount</th>
                          <th className="px-8 py-4 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {filteredCheques.map((cheque) => {
                          const state = CHEQUE_STATES[cheque.status as keyof typeof CHEQUE_STATES] || CHEQUE_STATES.UNKNOWN;
                          const slaStatus = getSLAStatus(cheque);
                          return (
                            <tr 
                              key={cheque.id} 
                              onClick={() => setSelectedChequeId(cheque.id)}
                              className="hover:bg-slate-50/80 cursor-pointer transition-colors group"
                            >
                              <td className="px-8 py-5">
                                <div className="flex items-center gap-4">
                                  <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-white transition-colors">
                                    <FileText className="w-5 h-5" />
                                  </div>
                                  <div>
                                    <p className="font-bold text-slate-900">{cheque.payee}</p>
                                    <div className="flex items-center gap-2">
                                      <span className="text-[9px] font-bold bg-slate-200 text-slate-600 px-1.5 rounded uppercase">{cheque.payment_type}</span>
                                      <span className="text-[10px] text-slate-400 font-mono">#{cheque.id.slice(0, 8)}</span>
                                    </div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-8 py-5">
                                <div className="flex flex-col gap-1">
                                  <span className={cn("px-3 py-1 rounded-full text-[10px] font-bold border w-fit", state.color)}>
                                    {state.label}
                                  </span>
                                  {cheque.status === 'SUBMITTED' && (
                                    <span className="text-[9px] text-amber-600 font-bold flex items-center gap-1">
                                      <Building2 className="w-3 h-3" />
                                      Awaiting Bank Review
                                    </span>
                                  )}
                                  {cheque.status === 'BANK_VERIFIED' && (
                                    <span className="text-[9px] text-blue-600 font-bold flex items-center gap-1">
                                      <Building2 className="w-3 h-3" />
                                      Awaiting Receiver Bank
                                    </span>
                                  )}
                                  {cheque.status === 'RECEIVER_ACK' && (
                                    <span className="text-[9px] text-indigo-600 font-bold flex items-center gap-1">
                                      <Clock className="w-3 h-3" />
                                      Scheduled for Clearing
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-8 py-5">
                                <div className="flex items-center gap-2">
                                  {slaStatus === 'SLA_BREACHED' ? (
                                    <div className="flex items-center gap-1.5 text-red-600 font-bold text-[10px]">
                                      <AlertCircle className="w-3 h-3" />
                                      BREACHED
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-1.5 text-emerald-600 font-bold text-[10px]">
                                      <CheckCircle2 className="w-3 h-3" />
                                      {slaStatus === 'SLA_MET' ? 'MET' : 'WITHIN SLA'}
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="px-8 py-5">
                                <p className="text-sm font-bold text-slate-900">{formatCurrency(cheque.amount)}</p>
                              </td>
                              <td className="px-8 py-5 text-right">
                                <button className="p-2 hover:bg-white rounded-lg transition-colors">
                                  <ChevronRight className="w-4 h-4 text-slate-400" />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {currentView === 'AUDIT_LOGS' && <AuditLogs />}
            {currentView === 'RISK_CENTER' && <RiskCenter />}
            {currentView === 'BANK_PORTAL' && <BankPortal />}
          </AnimatePresence>
        </div>
      </main>

      {/* Notifications */}
      <div className="fixed bottom-8 right-8 z-[100] space-y-4">
        <AnimatePresence>
          {notifications.map(n => (
            <motion.div
              key={n.id}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              className={cn(
                "px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border backdrop-blur-md",
                n.type === 'error' ? "bg-red-50 border-red-100 text-red-800" : "bg-white/90 border-slate-200 text-slate-800"
              )}
            >
              {n.type === 'error' ? <AlertCircle className="w-5 h-5 text-red-600" /> : <Bell className="w-5 h-5 text-indigo-600" />}
              <p className="text-sm font-bold">{n.message}</p>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showCreator && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <ChequeCreator 
              onSuccess={() => { setShowCreator(false); fetchCheques(); }} 
              onCancel={() => setShowCreator(false)} 
            />
          </div>
        )}
        {selectedChequeId && (
          <ChequeDetail 
            id={selectedChequeId} 
            onClose={() => setSelectedChequeId(null)} 
            onUpdate={fetchCheques}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
